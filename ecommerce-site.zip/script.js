// Initialize Firebase and global variables
const auth = firebase.auth();
const productCollection = db.collection('products');
const orderCollection = db.collection('orders');
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

// Auth state handling
auth.onAuthStateChanged(user => {
  const authBtn = document.getElementById('auth-button');
  if (authBtn) authBtn.textContent = user ? 'Logout' : 'Login';
  if (authBtn) authBtn.onclick = user ? logout : () => location.href = 'login.html';
});

// Register function
function register() {
  const email = document.getElementById('reg-email').value;
  const pass = document.getElementById('reg-password').value;
  auth.createUserWithEmailAndPassword(email, pass)
    .then(() => location.href = 'index.html')
    .catch(e => alert(e.message));
}

// Login function
function login() {
  const email = document.getElementById('login-email').value;
  const pass = document.getElementById('login-password').value;
  auth.signInWithEmailAndPassword(email, pass)
    .then(() => location.href = 'index.html')
    .catch(e => alert(e.message));
}

// Logout function
function logout() {
  auth.signOut().then(() => location.href = 'login.html');
}

// Load products (for products.html & admin.html)
function loadProducts() {
  productCollection.onSnapshot(snapshot => {
    const list = document.getElementById(window.location.pathname.includes('admin.html') ? 'productList' : 'product-list');
    list.innerHTML = '';
    snapshot.forEach(doc => {
      const data = doc.data();
      let html = '<div class="col-md-4 mb-3"><div class="card">';
      html += `<img src="${data.image}" class="card-img-top" alt="${data.name}">`;
      html += '<div class="card-body">';
      html += `<h5 class="card-title">${data.name}</h5>`;
      html += `<p class="card-text">₹${data.price}</p>`;
      if (window.location.pathname.includes('admin.html')) {
        html += `<button onclick="deleteProduct('${doc.id}')" class="btn btn-danger">Delete</button>`;
      } else {
        html += `<button onclick="addToCart('${doc.id}')" class="btn btn-primary">Add to Cart</button>`;
      }
      html += '</div></div></div>';
      list.innerHTML += html;
    });
  });
}

// Delete product (admin)
function deleteProduct(id) {
  productCollection.doc(id).delete();
}

// Add product (admin)
function addProduct() {
  const name = document.getElementById('productName').value;
  const price = parseInt(document.getElementById('productPrice').value);
  const image = document.getElementById('productImage').value;
  productCollection.add({ name, price, image });
}

// Cart functions
function addToCart(id) {
  cart.push(id);
  localStorage.setItem('cart', JSON.stringify(cart));
  document.getElementById('cart-count').textContent = cart.length;
}

// Show cart (cart.html)
function showCart() {
  if (!document.getElementById('cart-contents')) return;
  if (cart.length === 0) {
    document.getElementById('cart-contents').innerHTML = '<p>Cart is empty.</p>';
    return;
  }
  db.collection('products').get().then(snapshot => {
    let total = 0;
    let html = '<ul class="list-group">';
    snapshot.forEach(doc => {
      if (cart.includes(doc.id)) {
        const data = doc.data();
        total += data.price;
        html += `<li class="list-group-item d-flex justify-content-between align-items-center">
                   ${data.name} <span>₹${data.price}</span>
                 </li>`;
      }
    });
    html += '</ul><p class="mt-3">Total: ₹' + total + '</p>';
    document.getElementById('cart-contents').innerHTML = html;
    document.getElementById('checkout-button').onclick = () => checkout(total);
  });
}

// Checkout function
function checkout(amount) {
  auth.currentUser.getIdToken().then(token => {
    const options = {
      key: 'YOUR_RAZORPAY_KEY',
      amount: amount * 100,
      currency: 'INR',
      name: 'MyShop',
      handler: function(response) {
        // Save order on success
        orderCollection.add({
          user: auth.currentUser.email,
          productIds: cart,
          total: amount,
          timestamp: firebase.firestore.FieldValue.serverTimestamp()
        }).then(() => {
          alert('Payment successful!');
          localStorage.removeItem('cart');
          cart = [];
          window.location.href = 'index.html';
        });
      }
    };
    new Razorpay(options).open();
  });
}

// Load orders (admin)
function loadOrders() {
  if (!document.getElementById('orderList')) return;
  orderCollection.onSnapshot(snapshot => {
    let html = '<ul class="list-group">';
    snapshot.forEach(doc => {
      const o = doc.data();
      html += `<li class="list-group-item">
                 <strong>${o.user}</strong> - ₹${o.total} <br>
                 Order ID: ${doc.id}
               </li>`;
    });
    html += '</ul>';
    document.getElementById('orderList').innerHTML = html;
  });
}

// Initialize page-specific functions
window.onload = () => {
  loadProducts();
  showCart();
  loadOrders();
};